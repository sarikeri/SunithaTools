var enums = require('./../utils/enums');
var constants = require('./../utils/constants');
var logger = require('./../utils/logger');
var moment = require('moment');
var mapping = require('./mapping.json');
var gOrder = require('./../getInternal/getOrder');
var gSuborders = require('./../utils/suborders');
var async = require("async");

var getOrderInfo = function (orderId, callback) {
    let g = new gOrder('', { orderId: orderId }, {});
    g.execute()
        .then((order) => {
            return callback(null, order);
        })
        .catch((err) => {
            return callback(err, null);
        });
}

var getSuborders = function (orderId, callback) {
    let g = new gSuborders();
    g.get(orderId)
        .then((suborders) => {
            return callback(null, suborders);
        })
        .catch((err) => {
            return callback(err, null);
        });
}

class getOrder {
    constructor(context, metadata) {
        this.context = context;
        this.metadata = metadata;
    }

    execute() {
        var _this = this;
        let response = {};
        return new Promise(function (resolve, reject) {
            async.parallel([getOrderInfo.bind(null, _this.metadata.orderId), getSuborders.bind(null, _this.metadata.orderId)], function (err, results) {
                if (err) {
                    return _this.unexpectedError(err, response, resolve, reject);
                }
                let order = results[0];
                let suborders = results[1];
                if (order == null) {
                    response.errorFlags = constants.ORDER_ID_INVALID;
                    response.errorMessage = constants.ORDER_ID_INVALID_MESSAGE + constants.ERROR_MESSAGE_SEPARATOR;
                    return _this.failureHandler(response, resolve, reject);
                }
                order.orderPlacedDate = moment(order.orderPlacedDate).format("YYYY-MM-DDTHH:mm:ss.SSSZ");
                order.createDate = moment(order.createDate).format("YYYY-MM-DDTHH:mm:ss.SSSZ");
                response.clientId = order.clientId;
                response.resultCode = enums.resultCodes.success;
                response.failureDescription = '';
                response.order = {};
                response.order.siteId = order.siteId;
                response.order.clientOrderId = order.clientOrderId;
                response.order.clientOrderRefId = order.clientOrderRefId;
                response.order.orderId = order.orderId;
                response.order.fulfillmentStatus = mapping.orderFulfillmentStatus[order.status] != undefined ? mapping.orderFulfillmentStatus[order.status] : "In Progress";
                response.order.billingStatus = enums.orderBillingStatus.notApplicable;
                response.order.errorMessage = '';
                response.order.groups = [];
                if (suborders != null) {
                    for (let i = 0; i < order.groups.length; i++) {
                        let group = order.groups[i];
                        let orderGroup = {};
                        orderGroup.clientGroupId = group.groupId;
                        orderGroup.clientGroupRefId = '';
                        orderGroup.subGroups = [];
                        let subGroups = suborders.filter(function (so) {
                            return (so.groupId == group.groupId);
                        });
                        for (let k = 0; k < subGroups.length; k++) {
                            let subGroup = {};
                            let suborder = suborders[k];
                            subGroup.subGroupId = suborder.suborderId;
                            subGroup.targetedFulfillmentDate = null;
                            subGroup.targetedFulfillmentCenter = enums.targetedFulfillmentCenter[suborder.location.id];
                            subGroup.fulfillmentStatus = mapping.subGroupFulfillmentStatus[suborder.status] != undefined ? mapping.subGroupFulfillmentStatus[suborder.status] : "In Progress"
                            subGroup.billingStatus = enums.orderBillingStatus.notApplicable;
                            if (suborder.status == enums.suborderStatus.cancelled) {
                                subGroup.reason = suborder.cancellationReason;
                                subGroup.performedBy = suborder.cancelledBy;
                                subGroup.performedDateTime = suborder.cancelledDate;
                            }
                            else {
                                subGroup.performedBy = constants.OMS;
                                subGroup.performedDateTime = suborder.updateDate;
                            }
                            if (suborder.packages != null) {
                                subGroup.packages = [];
                                for (let p = 0; p < suborder.packages.length; p++) {
                                    let pkg = {};
                                    let suborderPackage = suborder.packages[p];
                                    pkg.packageId = suborderPackage.packageId;
                                    pkg.carrierAndService = '';
                                    pkg.carrierName = mapping.ptsOmsCarrierMapping[suborder.carrierId];
                                    pkg.shippedDateTime = suborder.shippedDate;
                                    pkg.carrierMethod = '';
                                    pkg.trackingURL = '';
                                    pkg.trackingNum = suborderPackage.trackingNumber;
                                    pkg.shippingCost = suborderPackage.shipCost;
                                    pkg.boxMeasure = {};
                                    pkg.boxMeasure.value = suborderPackage.weight;
                                    pkg.boxMeasure.units = enums.units.lbs;
                                    pkg.estimatedDeliveryDate = suborderPackage.estimatedArrivalDate;
                                    pkg.receivingBarcode = suborderPackage.receivingBarcode;
                                    pkg.lineItems = [];
                                    for (let l = 0; l < suborderPackage.lineItems.length; l++) {
                                        let lineItem = {};
                                        lineItem.quantity = suborderPackage.lineItems[l].qty;
                                        lineItem.clientLineItemId = suborderPackage.lineItems[l].lineItemId;
                                        lineItem.clientLineItemRefId = '';
                                        lineItem.unitCost = suborderPackage.lineItems[l].unitCost;
                                        pkg.lineItems.push(lineItem);
                                    }
                                    subGroup.packages.push(pkg);
                                }
                            }
                            else {
                                subGroup.lineItems = [];
                                for (let j = 0; j < suborder.lineItems.length; j++) {
                                    let lineItem = {};
                                    lineItem.quantity = '';
                                    lineItem.clientLineItemId = suborder.lineItems[j].lineItemId;
                                    lineItem.clientLineItemRefId = '';
                                    lineItem.unitCost = '';
                                    subGroup.lineItems.push(lineItem);
                                }
                            }
                            orderGroup.subGroups.push(subGroup);
                        }
                        response.order.groups.push(orderGroup);
                    }
                }
                response.responseTimestamp = moment().format("YYYY-MM-DDTHH:mm:ss.SSSZ");
                return resolve(response);
            });
        });
    }

    unexpectedError(error, response, resolve, reject) {
        if (error.stack) {
            logger.error(error.stack);
        } else {
            logger.error(error);
        }
        response.errorFlags = -1;
        response.errorMessage = 'An unexpected error has occurred.';
        return this.failureHandler(response, resolve, reject);
    }

    failureHandler(response, resolve, reject) {
        response.responseTimeStamp = moment().format('YYYY-MM-DDTHH:mm:ss.SSSZ');
        response.resultCode = enums.resultCodes.failure;
        response.failureDescription = constants.ORDER_RETRIEVAL_FAILURE_MESSAGE;
        return resolve(response);
    }
}

module.exports = getOrder;