var mongoDataProvider = require('./../dataProviders/mongoDataProvider');
var restClient = require('node-rest-client').Client;
var config = require('./../oapConfig');
var enums = require('./../utils/enums');
var logger = require('./../utils/logger');
var moment = require('moment');
var mapping = require('./mapping.json');

class getOrder {
    constructor(context, metadata) {
        this.context = context;
        this.metadata = metadata;
        this.client = new restClient();
    }

    execute() {
        var _this = this;
        let response = {};
        return new Promise(function (resolve, reject) {
            let dataProvider = new mongoDataProvider();
            dataProvider.findOne('orders', _this.metadata.query, _this.metadata.projection)
                .then((order) => {
                    order.orderPlacedDate = moment(order.orderPlacedDate).format("YYYY-MM-DDTHH:mm:ss.SSSZ");
                    order.createDate = moment(order.createDate).format("YYYY-MM-DDTHH:mm:ss.SSSZ");
                    response.clientId = order.clientId;
                    response.responseTimestamp = moment().format("YYYY-MM-DDTHH:mm:ss.SSSZ");
                    response.resultCode = enums.resultCodes.success;
                    response.failureDescription = '';
                    response.order = {};
                    response.order.orderSiteId = order.siteId;
                    response.order.clientOrderId = order.clientOrderId;
                    response.order.clientOrderRefId = order.clientOrderRefId;
                    response.order.orderId = order.orderId;
                    response.order.orderFulfillmentStatus = mapping.orderFulfillmentStatus[order.status]!=undefined?mapping.orderFulfillmentStatus[order.status]:"In Progress";
                    response.order.orderBillingStatus = enums.orderBillingStatus.completed;
                    //response.errorFlags='';
                    response.order.errorMessage = '';
                    response.order.groups = [];
                    let args = {
                        path: { orderId: order.orderId },
                        requestConfig: { timeout: config.workflowCreationAPITimeOut },
                        responseConfig: { timeout: config.workflowCreationAPITimeOut },
                    };
                    var req = _this.client.get(config.suborderAPI, args, function (data, svcResponse) {
                        if (svcResponse.statusCode >= 200 && svcResponse.statusCode < 300) {
                            for (let i = 0; i < order.groups.length; i++) {
                                let group = order.groups[i];
                                let orderGroup = {};
                                orderGroup.clientGroupId = group.groupId;
                                orderGroup.clientGroupReferenceId = '';
                                orderGroup.subGroups = [];
                                let suborders = data.filter(function (suborder1) {
                                    return (suborder1.groupId == group.groupId);
                                });
                                for (let k = 0; k < suborders.length; k++) {
                                    let suborderGroup = {};
                                    let suborder = suborders[k];
                                    suborderGroup.subGroupId = suborder.suborderId;
                                    suborderGroup.targetedFulfillmentDate = null;
                                    suborderGroup.targetedFulfillmentCenter = enums.targetedFulfillmentCenter[suborder.location.id];
                                    suborderGroup.fulfillmentStatus = mapping.subGroupFulfillmentStatus[suborder.status]!=undefined?mapping.subGroupFulfillmentStatus[suborder.status]:"In Progress"
                                    //suborderGroup.fulfillmentStatus = enums.subGroupFulfillmentStatus.shipped;
                                    suborderGroup.billingStatus = 'NotApplicable';
                                    if (suborderGroup.reason != null) {
                                        suborderGroup.reason = '';
                                    }
                                    suborderGroup.performedBy = '';
                                    suborderGroup.performedDateTime = moment(order.createDate).format("YYYY-MM-DDTHH:mm:ss.SSSZ");
                                    suborderGroup.packages = [];
                                    for (let p = 0; p < suborder.packages.length; p++) {
                                        let pkg = {};
                                        let suborderPackage=suborder.packages[p];
                                        pkg.packageId = suborderPackage.packageId;
                                        pkg.carrierAndService = '';
                                        pkg.carrierName = '';
                                        pkg.shippedDateTime = suborder.shippedDate;
                                        pkg.carrierMethod = '';
                                        pkg.trackingURL = '';
                                        pkg.trackingNumber = suborderPackage.trackingNumber;
                                        pkg.shippingCost = suborderPackage.shipCost;
                                        pkg.boxMeasure = {};
                                        pkg.boxMeasure.value = suborderPackage.weight;
                                        pkg.boxMeasure.units = 'lbs';
                                        pkg.estimatedDeliveryDate = suborderPackage.estimatedArrivalDate;
                                        pkg.receivingBarcode = suborderPackage.receivingBarcode;
                                        pkg.lineItems = [];
                                        for (let l = 0; l < suborderPackage.lineItems.length; l++) {
                                            let lineItem = {};
                                            lineItem.quantity = suborderPackage.lineItems[l].qty;
                                            lineItem.clientLineItemId = suborderPackage.lineItems[l].lineItemId;
                                            lineItem.clientLineItemReferenceId = '';
                                            lineItem.unitCost = suborderPackage.lineItems[l].unitCost;
                                            pkg.lineItems.push(lineItem);
                                        }
                                        suborderGroup.packages.push(pkg);
                                    }
                                    suborderGroup.lineItems = [];
                                    for (let j = 0; j < suborder.lineItems.length; j++) {
                                        let lineItem = {};
                                        lineItem.quantity = '';
                                        lineItem.clientLineItemId = suborder.lineItems[j].lineItemId;
                                        lineItem.clientLineItemReferenceId = '';
                                        lineItem.unitCost = '';
                                        suborderGroup.lineItems.push(lineItem);
                                    }
                                    orderGroup.subGroups.push(suborderGroup);
                                }
                                response.order.groups.push(orderGroup);
                            }
                            resolve(response);
                        }
                        else {
                            return reject(`http status code ${response.statusCode}; status message: ${response.statusMessage}`);
                        }
                    });

                    req.on('requestTimeout', function (req) {
                        logger.debug('request has expired');
                        req.abort();
                        return reject(`subOrder API timed out`);
                    });

                    req.on('error', function (err) {
                        reject(`API Error: ${err}`);
                    });
                })
                .catch((err) => {
                    response.order.errorFlags = 1;
                    response.resultCode = -1;
                    //response.errorFlags=-1
                    response.failureDescription = 'An unexpected error has occurred.';
                    logger.error(error.stack);
                    return reject(response);
                });
        });
    }

    getSubOrders(orderid) {
        let args = {
            path: { orderid: orderid },
            requestConfig: { timeout: config.workflowCreationAPITimeOut },
            responseConfig: { timeout: config.workflowCreationAPITimeOut },
        };
        var req = this.client.get("http://localhost:4001/suborder/v1/get", args, function (data, response) {
            if (response.statusCode >= 200 && response.statusCode < 300) {
                console.log(data);
            }
            else {
                reject(`http status code ${response.statusCode}; status message: ${response.statusMessage}`);
            }
        });

        req.on('requestTimeout', function (req) {
            logger.debug('request has expired');
            req.abort();
            console.log(`subOrder API timed out`);
        });

        req.on('error', function (err) {
            console.log(`API Error: ${err}`);
        });
    }
}

module.exports = getOrder;